const express = require("express");
const app = express();

const sendMessage = require("./router/sendMessage");
const showMessage = require("./router/showMessage");
const allMessage = require("./router/allMessage");
const updateSaw = require("./router/updateSaw");

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(sendMessage, showMessage, allMessage, updateSaw);
app.use("/static", express.static("public"));

app.listen(8080, () => {
  console.log("SERVER");
});

module.exports = app;