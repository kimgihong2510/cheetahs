const express = require("express");
const router = express.Router();
const mysql = require("mysql");

const connection = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "[qom3192mop!@]",
  database: "letter",
});

connection.connect();

router.get("/showMessage/:id", (req, res) => {
    console.log(req.params);
    const { id } = req.params;
    console.log(id);
    connection.query(
        "SELECT * FROM message WHERE id=?",
        [id],
        function (err, result) {
            console.log(id, result);
            if (err) {
                console.log(err);
                return res.status(403).json({
                    message: "query error",
                });
            } else {
                if (result.length == 0) {
                    return res.status(403).json({
                        message: "result empty"
                    });
                } else {
                    return res.status(200).json({
                        message: "success",
                        data: result
                    })
                }
            }
        }
    )
})

module.exports = router;