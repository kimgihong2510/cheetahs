const express = require("express");
const router = express.Router();
const mysql = require("mysql");

const connection = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "[qom3192mop!@]",
  database: "letter",
});

connection.connect();

router.get("/allMessage", (req, res) => {
    connection.query(
        "SELECT id, lat, lon, cat, cnt, saw, eti FROM message WHERE saw < cnt && eti > now()",
        function (err, result) {
            if (err) {
                console.log(err);
                return res.status(403).json({
                    message: "query error",
                });
            } else {
                if (result.length == 0) {
                    return res.status(403).json({
                        message: "result empty"
                    });
                } else {
                    return res.status(200).json({
                        message: "success",
                        data: result
                    })
                }
            }
        }
    )
})

module.exports = router;