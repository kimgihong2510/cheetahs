const express = require("express");
const router = express.Router();
const mysql = require("mysql");

const connection = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "[qom3192mop!@]",
  database: "letter",
});

connection.connect();

router.post("/sendMessage", (req, res) => {
    const { body } = req;
    console.log(body);
    const lat = body.lat;
    const lon = body.lon;
    const cat = body.cat;
    const cnt = body.cnt;
    const saw = body.saw;
    const eti = body.eti;
    const text = body.text;
    const name = body.name;
    const number = body.number;
    const major = body.major;
    const tact = body.tact;
    connection.query(
        "INSERT INTO message(lat,lon,cat,cnt,saw,eti,text,name,number,major,tact) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
        [lat, lon, cat, cnt, saw, eti, text, name, number, major, tact],
        function (err, result) {
            if(err) {
                console.log(err);
            } else {
                return res.status(200).json({
                    message: "메시지 저장 성공",
                });
            }
        }
    )
})

module.exports = router;