const express = require("express");
const router = express.Router();
const mysql = require("mysql");

const connection = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "[qom3192mop!@]",
  database: "letter",
});

connection.connect();

router.post("/updateMessage", (req, res) => {
    const { body } = req;
    console.log(body);
    const userID = body.userID;
    const messageID = body.messageID;
    connection.query(
        "INSERT INTO messageID(userID, messageID) VALUES(?,?)",
        [userID, messageID],
        function (err, result) {
            if(err) {
                console.log(err);
            } else {
                return res.status(200).json({
                    message: "messageID값 update 성공",
                });
            }
        }
    )
})

module.exports = router;